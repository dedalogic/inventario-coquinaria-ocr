# 🎯 INSTRUCCIONES PARA INTEGRAR OCR EN TU HTML

## ✅ Archivos Creados

He creado los siguientes archivos que necesitas subir a GitHub:

1. **netlify.toml** - Configuración de Netlify
2. **package.json** - Dependencias del proyecto  
3. **netlify/functions/process-guia.js** - Función serverless para OCR

## 📝 MODIFICACIONES EN TU index.html

### PASO 1: Reemplazar la función `handleScan`

**BUSCA (aprox línea 325):**

```javascript
function handleScan(input) {
    if (input.files && input.files[0]) {
        showToast("Procesando Guía...");
        setTimeout(() => {
            const fakeDoc = "GD-" + Math.floor(Math.random() * 100000);
            currentDocNumber = fakeDoc;
            document.getElementById('docNumberInput').value = fakeDoc;
            const randomProds = rawProducts.sort(() => 0.5 - Math.random()).slice(0, 4);
            randomProds.forEach(p => {
                const q = Math.floor(Math.random() * 10) + 1;
                dataReception[p.sku] = q;
            });
            
            saveData();
            renderProducts();
            showToast(`Guía ${fakeDoc} procesada.`);
        }, 1500);
    }
}
```

**REEMPLAZA POR:**

```javascript
async function handleScan(input) {
    if (!input.files || !input.files[0]) return;
    
    const file = input.files[0];
    
    // Validar tamaño (máximo 10MB)
    if (file.size > 10 * 1024 * 1024) {
        showToast("Imagen muy grande. Máximo 10MB.");
        return;
    }
    
    showToast("Procesando guía con Google Vision AI...");
    
    try {
        // Convertir imagen a base64
        const reader = new FileReader();
        const base64 = await new Promise((resolve, reject) => {
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
        
        // Llamar a la función de Netlify
        const response = await fetch('/.netlify/functions/process-guia', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ image: base64 })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Error procesando imagen');
        }
        
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'No se pudo procesar la guía');
        }
        
        // Procesar resultados
        procesarGuiaOCR(data);
        
    } catch (error) {
        console.error('Error:', error);
        showToast("Error: " + error.message);
    }
}
```

### PASO 2: Agregar nuevas funciones

**AGREGAR AL FINAL del `<script>`, ANTES del `</script>` final:**

```javascript
// === FUNCIONES OCR ===
function procesarGuiaOCR(data) {
    // Actualizar número de guía
    if (data.numeroGuia) {
        currentDocNumber = data.numeroGuia;
        const docInput = document.getElementById('docNumberInput');
        if (docInput) docInput.value = data.numeroGuia;
    }
    
    // Procesar productos detectados
    if (data.productos && data.productos.length > 0) {
        let productosImportados = 0;
        let productosNoEncontrados = [];
        
        data.productos.forEach(prod => {
            const productoExiste = rawProducts.find(p => p.sku === prod.codigo);
            
            if (productoExiste) {
                dataReception[prod.codigo] = prod.cantidad;
                productosImportados++;
            } else {
                productosNoEncontrados.push(prod.codigo);
            }
        });
        
        saveData();
        renderProducts();
        
        // Mostrar resumen
        mostrarResumenGuia(data, productosImportados, productosNoEncontrados);
        
    } else {
        showToast("⚠️ No se detectaron productos en la guía");
    }
}

function mostrarResumenGuia(data, importados, noEncontrados) {
    const modal = document.getElementById('shareModal');
    const modalContent = modal.querySelector('.modal-content');
    
    const totalUnidades = data.productos.reduce((sum, p) => sum + p.cantidad, 0);
    
    let html = `
        <h3 class="modal-title">Guía Procesada ✅</h3>
        
        <div style="background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%); border: 2px solid #f87171; border-radius: 12px; padding: 15px; margin-bottom: 20px;">
            <div style="font-size: 12px; color: #7f1d1d; font-weight: 600; margin-bottom: 3px;">Nº GUÍA</div>
            <div style="font-size: 24px; font-weight: 700; color: #991b1b; letter-spacing: 1px;">${data.numeroGuia || 'N/A'}</div>
        </div>
        
        <div style="background: #eff6ff; border-radius: 10px; padding: 15px; margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                <span style="color: #1e40af; font-weight: 600;">Productos importados:</span>
                <span style="color: #059669; font-weight: 700; font-size: 18px;">✓ ${importados}</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                <span style="color: #1e40af; font-weight: 600;">Total unidades:</span>
                <span style="color: #1e40af; font-weight: 700; font-size: 18px;">${totalUnidades}</span>
            </div>
    `;
    
    if (noEncontrados.length > 0) {
        html += `
            <div style="display: flex; justify-content: space-between; padding-top: 8px; border-top: 1px solid #bfdbfe;">
                <span style="color: #dc2626; font-weight: 600;">SKUs no encontrados:</span>
                <span style="color: #dc2626; font-weight: 700; font-size: 18px;">⚠️ ${noEncontrados.length}</span>
            </div>
        `;
    }
    
    html += '</div><div style="max-height: 300px; overflow-y: auto; margin-bottom: 15px;">';
    
    // Listar productos
    data.productos.forEach(prod => {
        const existe = rawProducts.find(p => p.sku === prod.codigo);
        const borderColor = existe ? '#10b981' : '#ef4444';
        const bgColor = existe ? '#f0fdf4' : '#fee2e2';
        
        html += `
            <div style="background: ${bgColor}; border-left: 3px solid ${borderColor}; border-radius: 6px; padding: 10px; margin-bottom: 8px; font-size: 13px;">
                <div style="font-weight: 600; color: #1e293b; margin-bottom: 3px;">${prod.descripcion}</div>
                <div style="display: flex; justify-content: space-between; color: #64748b;">
                    <span>SKU: ${prod.codigo}</span>
                    <span style="font-weight: 700;">Cant: ${prod.cantidad}</span>
                </div>
            </div>
        `;
    });
    
    html += `
        </div>
        <button class="btn-cta" onclick="closeShareModal()" style="width: 100%; margin-top: 10px;">
            Continuar con Recepción
        </button>
    `;
    
    modalContent.innerHTML = html;
    modal.classList.add('active');
}
```

## 🚀 PASOS PARA SUBIR A GITHUB

### 1. Crea el repositorio en GitHub

```bash
Nombre: inventario-coquinaria-ocr
Descripción: Sistema OCR para guías de despacho
Tipo: Public (o Private)
✓ Add README
✓ Add .gitignore (Node template)
```

### 2. Sube los archivos

**Opción A: Desde la interfaz web de GitHub**

1. Click en "Add file" → "Upload files"
2. Arrastra estos archivos:
   - `netlify.toml`
   - `package.json`
   - `netlify/functions/process-guia.js` (crea la carpeta primero)
   - `index.html` (modificado con los cambios de arriba)
   - `manifest.json` (tu archivo actual)

**Opción B: Desde git CLI**

```bash
git clone tu-repositorio.git
cd inventario-coquinaria-ocr

# Copiar archivos aquí

git add .
git commit -m "Add OCR functionality with Google Vision AI"
git push origin main
```

## 🌐 CONFIGURAR NETLIFY

### 1. Conectar repositorio

1. Ve a [Netlify](https://app.netlify.com)
2. Click en "Add new site" → "Import an existing project"
3. Selecciona GitHub y autoriza
4. Selecciona tu repositorio `inventario-coquinaria-ocr`
5. Click en "Deploy site"

### 2. Configurar Google Cloud Vision API

#### A. Crear proyecto en Google Cloud

1. Ve a [Google Cloud Console](https://console.cloud.google.com)
2. Crea un nuevo proyecto o selecciona uno existente
3. Activa la API de Vision:
   - Ve a "APIs & Services" → "Library"
   - Busca "Cloud Vision API"
   - Click en "Enable"

#### B. Crear Service Account

1. Ve a "IAM & Admin" → "Service Accounts"
2. Click en "Create Service Account"
3. Nombre: `netlify-vision-ocr`
4. Role: `Cloud Vision API User`
5. Click en "Create and Continue"
6. Click en "Done"

#### C. Generar credenciales JSON

1. Click en el service account creado
2. Ve a "Keys" → "Add Key" → "Create new key"
3. Selecciona "JSON"
4. Descarga el archivo (por ejemplo: `credentials.json`)

#### D. Configurar en Netlify

1. En tu sitio de Netlify, ve a "Site settings" → "Environment variables"
2. Click en "Add a variable"
3. Crea esta variable:

```
Key: GOOGLE_APPLICATION_CREDENTIALS_JSON
Value: [pega todo el contenido del archivo JSON descargado]
```

**Ejemplo del JSON:**

```json
{
  "type": "service_account",
  "project_id": "tu-proyecto-id",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "netlify-vision-ocr@tu-proyecto.iam.gserviceaccount.com",
  ...
}
```

4. Click en "Save"
5. Redeploy el sitio: "Deploys" → "Trigger deploy" → "Deploy site"

## ✅ PROBAR LA INTEGRACIÓN

1. Ve a tu sitio desplegado (ejemplo: `https://tu-sitio.netlify.app`)
2. Ve a "Stock" → "Recepción"
3. Click en "Escanear Guía" (icono de cámara)
4. Toma una foto de una guía o sube una imagen
5. Espera a que se procese
6. Verás un modal con los resultados

## 🐛 TROUBLESHOOTING

### Error: "Google Vision API credentials not configured"
- Verifica que la variable de entorno `GOOGLE_APPLICATION_CREDENTIALS_JSON` esté configurada en Netlify
- Verifica que el JSON sea válido (sin espacios extra)

### Error: "No se detectó texto en la imagen"
- La imagen puede estar borrosa
- Intenta con mejor iluminación
- Asegúrate de que el texto sea legible

### Error: "No se detectaron productos"
- Verifica que la guía tenga el formato correcto (SKU + descripción + cantidad)
- Puedes ajustar los patrones de búsqueda en `procesarTextoGuia()` en `process-guia.js`

## 📊 FORMATO ESPERADO DE LA GUÍA

Para mejores resultados, las guías deben tener:

```
GUÍA DE DESPACHO: GD-12345

SKU     DESCRIPCIÓN                    CANTIDAD
80001   Cuchillo aperitivo            5 un
80002   Cuchillo para pan             3 un
80003   Espátula Coquinaria           10 un
```

¡Listo! Tu sistema OCR está configurado y funcionando 🎉
