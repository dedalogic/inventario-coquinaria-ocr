# 📦 Sistema de Inventario Coquinaria con OCR

Sistema web de gestión de inventario para Coquinaria con funcionalidad OCR para procesar automáticamente guías de despacho mediante Google Cloud Vision AI.

## 🌟 Características

- ✅ **Catálogo de productos** completo con búsqueda y filtros
- 📊 **Control de stock** con 3 modos: Conteo, Recepción y Sugerido
- 📷 **OCR con Google Vision AI** para escanear guías de despacho
- 📱 **PWA** - Funciona como app móvil
- 💾 **Almacenamiento local** - No requiere backend
- 📨 **Exportación** via WhatsApp y Email
- 📅 **Historial** de operaciones

## 🚀 Demo

🔗 [Ver Demo en Vivo](https://tu-sitio.netlify.app)

## 🛠️ Tecnologías

- HTML5 / CSS3 / JavaScript (Vanilla)
- Google Cloud Vision API
- Netlify Functions (Serverless)
- PWA (Progressive Web App)

## 📋 Instalación

### 1. Clonar el repositorio

```bash
git clone https://github.com/tu-usuario/inventario-coquinaria-ocr.git
cd inventario-coquinaria-ocr
```

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar Google Cloud Vision API

1. Crea un proyecto en [Google Cloud Console](https://console.cloud.google.com)
2. Activa la Cloud Vision API
3. Crea un Service Account con rol "Cloud Vision API User"
4. Descarga las credenciales JSON

### 4. Desplegar en Netlify

1. Conecta tu repositorio a Netlify
2. Configura la variable de entorno:
   - Key: `GOOGLE_APPLICATION_CREDENTIALS_JSON`
   - Value: `[contenido completo del JSON de credenciales]`
3. Despliega el sitio

## 📱 Uso

### Modo Catálogo
- Navega por todos los productos
- Filtra por categoría
- Busca por nombre, SKU, marca u origen
- Ve detalles completos de cada producto

### Modo Stock

#### Conteo
1. Ve a **Stock** → **Conteo**
2. Ajusta cantidades con +/-
3. Finaliza y comparte el reporte

#### Recepción con OCR
1. Ve a **Stock** → **Recepción**
2. Click en **Escanear Guía** 📷
3. Toma foto o sube imagen de la guía
4. El sistema detectará automáticamente:
   - Número de guía
   - SKUs de productos
   - Cantidades
5. Revisa el resumen y continúa

#### Sugerido
1. Ve a **Stock** → **Sugerido**
2. Ingresa cantidades sugeridas
3. Genera reporte

## 📊 Formato de Guía para OCR

Para mejores resultados, las guías deben tener:

```
GUÍA DE DESPACHO: GD-12345

SKU     DESCRIPCIÓN                    CANTIDAD
80001   Cuchillo aperitivo            5 un
80002   Cuchillo para pan             3 un
80003   Espátula Coquinaria           10 un
```

## 🔧 Desarrollo Local

```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Iniciar servidor de desarrollo
netlify dev
```

El sitio estará disponible en `http://localhost:8888`

## 📁 Estructura del Proyecto

```
inventario-coquinaria-ocr/
├── index.html                    # Aplicación principal
├── manifest.json                 # Configuración PWA
├── netlify.toml                  # Configuración Netlify
├── package.json                  # Dependencias
├── netlify/
│   └── functions/
│       └── process-guia.js       # Función OCR serverless
└── README.md
```

## 🐛 Troubleshooting

### OCR no detecta texto
- Verifica que la imagen tenga buena iluminación
- Asegúrate de que el texto sea legible
- Revisa que las credenciales de Google estén configuradas

### Productos no se importan
- Verifica que los SKUs en la guía coincidan con los del sistema
- Revisa el formato de la guía
- Ajusta los patrones de búsqueda en `process-guia.js` si es necesario

## 📄 Licencia

MIT

## 👤 Autor

Tu Nombre - [@tu_usuario](https://github.com/tu-usuario)

## 🙏 Agradecimientos

- Google Cloud Vision API
- Netlify
- Comunidad de desarrolladores

---

⭐ Si te gusta este proyecto, dale una estrella!
